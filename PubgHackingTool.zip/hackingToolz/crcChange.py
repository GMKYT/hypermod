import crc32forcer

crc32forcer.access("brute_force_AESKey_Pubg.exe", "72ccf1f8")